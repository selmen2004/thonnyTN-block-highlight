Plug-in for Thonny IDE which highlights the current code block
